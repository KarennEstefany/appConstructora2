package com.constructora.controllers;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.constructora.dto.ClienteInteresadoResponseDTO;
import com.constructora.dto.ProyectoRequestDTO;
import com.constructora.dto.ProyectoResponseDTO;
import com.constructora.dto.ViviendaResponseDTO;
import com.constructora.services.ClienteInteresadoService;
import com.constructora.services.ProyectoService;
import com.constructora.services.ViviendaService;

import jakarta.validation.Valid;

@RequestMapping ("/api/proyectos")
public class ProyectoController {
    private final ProyectoService proyectoService;
    private final ViviendaService viviendaService;
    private final ClienteInteresadoService clienteInteresadoService;
    public ProyectoController(ProyectoService proyectoService, ViviendaService viviendaService,
            ClienteInteresadoService clienteInteresadoService) {
        this.proyectoService = proyectoService;
        this.viviendaService = viviendaService;
        this.clienteInteresadoService = clienteInteresadoService;
    }

    @GetMapping 
    public ResponseEntity<List<ProyectoResponseDTO>> obtenerTodos(){
        return ResponseEntity.ok(proyectoService.obtenerTodos());
    }

     @GetMapping 
    public ResponseEntity<List<ProyectoResponseDTO>> obtenerDestacados(){
        return ResponseEntity.ok(proyectoService.obtenerDestacados());
    }

     @GetMapping 
    public ResponseEntity<List<ProyectoResponseDTO>> obtenerPorId(@PathVariable Long id){
        return ResponseEntity.ok(proyectoService.obtenerPorId(id));
    }

     @GetMapping 
    public ResponseEntity<List<ViviendaResponseDTO>> obtenerViviendas(@PathVariable Long proyectoId){
        return ResponseEntity.ok(viviendaService.obtenerPorProyecto(proyectoId));

    }
     @GetMapping 
    public ResponseEntity<List<ClienteInteresadoResponseDTO>> obtenerClientes(@PathVariable Long proyectoId){
        return ResponseEntity.ok(clienteInteresadoService.obtenerPorProyecto(proyectoId));

    }

    @PostMapping 
    public ResponseEntity<ProyectoResponseDTO> crear(@Valid @RequestBody ProyectoRequestDTO dto){
        ProyectoResponseDTO creado = proyectoService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping 
    public ResponseEntity<ProyectoResponseDTO> actualizar(@PathVariable Long id, @Valid @RequestBody ProyectoRequestDTO dto){

       
        return ResponseEntity.ok(proyectoService.actualizar(id,dto));
    }
    @DeleteMapping 
    public ResponseEntity<ProyectoResponseDTO> eliminar(@PathVariable Long id){
        proyectoService.eliminar(id):
        return ResponseEntity.noContent().build();
    }
    

    
    
    
    
}
